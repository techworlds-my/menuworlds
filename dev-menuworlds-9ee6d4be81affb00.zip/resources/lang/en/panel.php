<?php

return [
    'site_title' => 'Menuworlds',
];
