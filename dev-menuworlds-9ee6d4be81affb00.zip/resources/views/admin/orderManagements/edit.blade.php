@extends('layouts.admin')
@section('content')

<div class="card">
    <div class="card-header">
        {{ trans('global.edit') }} {{ trans('cruds.orderManagement.title_singular') }}
    </div>

    <div class="card-body">
        <form method="POST" action="{{ route("admin.order-managements.update", [$orderManagement->id]) }}" enctype="multipart/form-data">
            @method('PUT')
            @csrf
            <div class="form-group">
                <label class="required" for="order">{{ trans('cruds.orderManagement.fields.order') }}</label>
                <input class="form-control {{ $errors->has('order') ? 'is-invalid' : '' }}" type="text" name="order" id="order" value="{{ old('order', $orderManagement->order) }}" required>
                @if($errors->has('order'))
                    <div class="invalid-feedback">
                        {{ $errors->first('order') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.order_helper') }}</span>
            </div>
            <div class="form-group">
                <label class="required" for="username">{{ trans('cruds.orderManagement.fields.username') }}</label>
                <input class="form-control {{ $errors->has('username') ? 'is-invalid' : '' }}" type="text" name="username" id="username" value="{{ old('username', $orderManagement->username) }}" required>
                @if($errors->has('username'))
                    <div class="invalid-feedback">
                        {{ $errors->first('username') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.username_helper') }}</span>
            </div>
            <div class="form-group">
                <label class="required" for="address">{{ trans('cruds.orderManagement.fields.address') }}</label>
                <input class="form-control {{ $errors->has('address') ? 'is-invalid' : '' }}" type="text" name="address" id="address" value="{{ old('address', $orderManagement->address) }}" required>
                @if($errors->has('address'))
                    <div class="invalid-feedback">
                        {{ $errors->first('address') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.address_helper') }}</span>
            </div>
            <div class="form-group">
                <label class="required" for="price">{{ trans('cruds.orderManagement.fields.price') }}</label>
                <input class="form-control {{ $errors->has('price') ? 'is-invalid' : '' }}" type="number" name="price" id="price" value="{{ old('price', $orderManagement->price) }}" step="0.01" required>
                @if($errors->has('price'))
                    <div class="invalid-feedback">
                        {{ $errors->first('price') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.price_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="delivery_charge">{{ trans('cruds.orderManagement.fields.delivery_charge') }}</label>
                <input class="form-control {{ $errors->has('delivery_charge') ? 'is-invalid' : '' }}" type="number" name="delivery_charge" id="delivery_charge" value="{{ old('delivery_charge', $orderManagement->delivery_charge) }}" step="0.01">
                @if($errors->has('delivery_charge'))
                    <div class="invalid-feedback">
                        {{ $errors->first('delivery_charge') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.delivery_charge_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="tax">{{ trans('cruds.orderManagement.fields.tax') }}</label>
                <input class="form-control {{ $errors->has('tax') ? 'is-invalid' : '' }}" type="number" name="tax" id="tax" value="{{ old('tax', $orderManagement->tax) }}" step="0.01">
                @if($errors->has('tax'))
                    <div class="invalid-feedback">
                        {{ $errors->first('tax') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.tax_helper') }}</span>
            </div>
            <div class="form-group">
                <label class="required" for="total">{{ trans('cruds.orderManagement.fields.total') }}</label>
                <input class="form-control {{ $errors->has('total') ? 'is-invalid' : '' }}" type="number" name="total" id="total" value="{{ old('total', $orderManagement->total) }}" step="0.01" required>
                @if($errors->has('total'))
                    <div class="invalid-feedback">
                        {{ $errors->first('total') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.total_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="comment">{{ trans('cruds.orderManagement.fields.comment') }}</label>
                <input class="form-control {{ $errors->has('comment') ? 'is-invalid' : '' }}" type="text" name="comment" id="comment" value="{{ old('comment', $orderManagement->comment) }}">
                @if($errors->has('comment'))
                    <div class="invalid-feedback">
                        {{ $errors->first('comment') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.comment_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="merchant_id">{{ trans('cruds.orderManagement.fields.merchant') }}</label>
                <select class="form-control select2 {{ $errors->has('merchant') ? 'is-invalid' : '' }}" name="merchant_id" id="merchant_id">
                    @foreach($merchants as $id => $merchant)
                        <option value="{{ $id }}" {{ (old('merchant_id') ? old('merchant_id') : $orderManagement->merchant->id ?? '') == $id ? 'selected' : '' }}>{{ $merchant }}</option>
                    @endforeach
                </select>
                @if($errors->has('merchant'))
                    <div class="invalid-feedback">
                        {{ $errors->first('merchant') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.merchant_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="payment_method_id">{{ trans('cruds.orderManagement.fields.payment_method') }}</label>
                <select class="form-control select2 {{ $errors->has('payment_method') ? 'is-invalid' : '' }}" name="payment_method_id" id="payment_method_id">
                    @foreach($payment_methods as $id => $payment_method)
                        <option value="{{ $id }}" {{ (old('payment_method_id') ? old('payment_method_id') : $orderManagement->payment_method->id ?? '') == $id ? 'selected' : '' }}>{{ $payment_method }}</option>
                    @endforeach
                </select>
                @if($errors->has('payment_method'))
                    <div class="invalid-feedback">
                        {{ $errors->first('payment_method') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.payment_method_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="status_id">{{ trans('cruds.orderManagement.fields.status') }}</label>
                <select class="form-control select2 {{ $errors->has('status') ? 'is-invalid' : '' }}" name="status_id" id="status_id">
                    @foreach($statuses as $id => $status)
                        <option value="{{ $id }}" {{ (old('status_id') ? old('status_id') : $orderManagement->status->id ?? '') == $id ? 'selected' : '' }}>{{ $status }}</option>
                    @endforeach
                </select>
                @if($errors->has('status'))
                    <div class="invalid-feedback">
                        {{ $errors->first('status') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.status_helper') }}</span>
            </div>
            <div class="form-group">
                <div class="form-check {{ $errors->has('voucher_used') ? 'is-invalid' : '' }}">
                    <input type="hidden" name="voucher_used" value="0">
                    <input class="form-check-input" type="checkbox" name="voucher_used" id="voucher_used" value="1" {{ $orderManagement->voucher_used || old('voucher_used', 0) === 1 ? 'checked' : '' }}>
                    <label class="form-check-label" for="voucher_used">{{ trans('cruds.orderManagement.fields.voucher_used') }}</label>
                </div>
                @if($errors->has('voucher_used'))
                    <div class="invalid-feedback">
                        {{ $errors->first('voucher_used') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.voucher_used_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="voucher_id">{{ trans('cruds.orderManagement.fields.voucher') }}</label>
                <select class="form-control select2 {{ $errors->has('voucher') ? 'is-invalid' : '' }}" name="voucher_id" id="voucher_id">
                    @foreach($vouchers as $id => $voucher)
                        <option value="{{ $id }}" {{ (old('voucher_id') ? old('voucher_id') : $orderManagement->voucher->id ?? '') == $id ? 'selected' : '' }}>{{ $voucher }}</option>
                    @endforeach
                </select>
                @if($errors->has('voucher'))
                    <div class="invalid-feedback">
                        {{ $errors->first('voucher') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.voucher_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="order_type_id">{{ trans('cruds.orderManagement.fields.order_type') }}</label>
                <select class="form-control select2 {{ $errors->has('order_type') ? 'is-invalid' : '' }}" name="order_type_id" id="order_type_id">
                    @foreach($order_types as $id => $order_type)
                        <option value="{{ $id }}" {{ (old('order_type_id') ? old('order_type_id') : $orderManagement->order_type->id ?? '') == $id ? 'selected' : '' }}>{{ $order_type }}</option>
                    @endforeach
                </select>
                @if($errors->has('order_type'))
                    <div class="invalid-feedback">
                        {{ $errors->first('order_type') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.order_type_helper') }}</span>
            </div>
            <div class="form-group">
                <label for="time_needed">{{ trans('cruds.orderManagement.fields.time_needed') }}</label>
                <input class="form-control datetime {{ $errors->has('time_needed') ? 'is-invalid' : '' }}" type="text" name="time_needed" id="time_needed" value="{{ old('time_needed', $orderManagement->time_needed) }}">
                @if($errors->has('time_needed'))
                    <div class="invalid-feedback">
                        {{ $errors->first('time_needed') }}
                    </div>
                @endif
                <span class="help-block">{{ trans('cruds.orderManagement.fields.time_needed_helper') }}</span>
            </div>
            <div class="form-group">
                <button class="btn btn-danger" type="submit">
                    {{ trans('global.save') }}
                </button>
            </div>
        </form>
    </div>
</div>



@endsection